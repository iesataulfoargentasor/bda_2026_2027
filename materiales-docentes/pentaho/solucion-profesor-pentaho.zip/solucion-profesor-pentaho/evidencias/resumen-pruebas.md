# Resultado de las verificaciones

PDI 9.4.0.0-343. Las 25 ejecuciones dieron el resultado esperado.

| Prueba | Esperado | Código del motor | Resultado |
| --- | --- | ---: | --- |
| 01_primera_ejecucion | éxito | 0 | CORRECTO |
| 02_repeticion | éxito | 0 | CORRECTO |
| 03_falta_entrada | error | 1 | CORRECTO |
| 04_solo_cabecera_validar_informe | error | 1 | CORRECTO |
| 04_solo_cabecera_validar_sin_cobro | error | 1 | CORRECTO |
| 05_total_incorrecto | error | 1 | CORRECTO |
| 06_recuperacion | éxito | 0 | CORRECTO |
| 07_identificador_invalido | error | 1 | CORRECTO |
| 08_identificador_duplicado | error | 1 | CORRECTO |
| 09_job_validacion_fallida | error | 1 | CORRECTO |
| paquete_A001 | éxito | 0 | CORRECTO |
| paquete_A002 | éxito | 0 | CORRECTO |
| paquete_A003 | éxito | 0 | CORRECTO |
| paquete_A004 | éxito | 0 | CORRECTO |
| paquete_A005 | éxito | 0 | CORRECTO |
| paquete_A006 | éxito | 0 | CORRECTO |
| paquete_A007 | éxito | 0 | CORRECTO |
| paquete_A008 | éxito | 0 | CORRECTO |
| paquete_A009 | éxito | 0 | CORRECTO |
| paquete_A010 | éxito | 0 | CORRECTO |
| paquete_A011 | éxito | 0 | CORRECTO |
| paquete_A012 | éxito | 0 | CORRECTO |
| paquete_A013 | éxito | 0 | CORRECTO |
| paquete_A014 | éxito | 0 | CORRECTO |
| paquete_A015 | éxito | 0 | CORRECTO |
